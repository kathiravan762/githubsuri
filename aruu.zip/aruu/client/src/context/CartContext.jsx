import React, { createContext, useContext, useState, useEffect } from 'react';

// Create the context
const CartContext = createContext();

// Provide the context
export const CartProvider = ({ children }) => {
 const [cartItems, setCartItems] = useState(() => {
  const storedCart = localStorage.getItem("cartItems");
  return storedCart ? JSON.parse(storedCart) : [];
});

  // Load cart from localStorage on first load
  useEffect(() => {
    const storedCart = localStorage.getItem('cartItems');
    if (storedCart) {
      setCartItems(JSON.parse(storedCart));
    }
  }, []);

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('cartItems', JSON.stringify(cartItems));
  }, [cartItems]);
  

  // Add item to cart
 const addToCart = (item) => {
  const existingItem = cartItems.find((i) => i._id === item._id);
  if (existingItem) {
    setCartItems((prev) =>
      prev.map((i) =>
        i._id === item._id
          ? {
              ...i,
              quantity: i.quantity + (item.quantity || 1),
            }
          : i
      )
    );
  } else {
    setCartItems([...cartItems, { ...item, quantity: item.quantity || 1 }]);
  }
};

  // Remove item completely from cart
  const removeFromCart = (id) => {
    setCartItems(cartItems.filter((item) => item._id !== id));
  };

  // Decrease item quantity
  const decreaseQuantity = (id) => {
    setCartItems((prev) =>
      prev
        .map((item) =>
          item._id === id ? { ...item, quantity: item.quantity - 1 } : item
        )
        .filter((item) => item.quantity > 0)
    );
  };

  // Clear entire cart
  const clearCart = () => {
    setCartItems([]);
  };

  return (
    <CartContext.Provider
      value={{ cartItems, addToCart, removeFromCart, decreaseQuantity, clearCart }}
    >
      {children}
    </CartContext.Provider>
  );
};

// Custom hook to use the cart
export const useCart = () => useContext(CartContext);