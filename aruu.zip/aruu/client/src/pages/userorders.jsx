import api from '../api/axios'; 
import React, { useState, useEffect } from 'react';
import { toast } from 'react-toastify';

const UserOrders = () => {
  const [orderList, setOrderList] = useState([]);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      const res = await api.get('http://localhost:5000/api/orders');
      setOrderList(res.data);
    } catch (err) {
      console.error('Error fetching orders:', err);
    }
  };

  const updateOrderStatus = async (orderId, newStatus) => {
    try {
      await api.put(`http://localhost:5000/api/orders/${orderId}/status`, {
        status: newStatus,
      });
      toast.success("✅ Order status updated");
      fetchOrders(); // refresh list after update
    } catch (err) {
      console.error('Error updating order status:', err);
      toast.error("Failed to update status");
    }
  };

  return (
    <div>
      <h3 style={{ marginTop: '40px' }}>User Orders</h3>
      <div className='order-list'>
        {orderList.length === 0 ? (
          <p>No orders yet.</p>
        ) : (
          <div style={{ marginTop: '10px' }}>
            {orderList.map((order) => (
              <div key={order._id}
                style={{
                  background: '#f8f8f8',
                  padding: '10px',
                  marginBottom: '10px',
                  borderRadius: '6px',
                  boxShadow: '0 0 5px rgba(0,0,0,0.1)'
                }}>
                
                {/* Show all items in the order */}
                <p><strong>Items:</strong></p>
                {order.items.map((item, idx) => (
                  <div key={idx} style={{ marginLeft: "10px" }}>
                    🍽 {item.foodName} × {item.quantity} = ₹{item.totalPrice}
                  </div>
                ))}

                <p><strong>Email:</strong> {order.email}</p>
                <p><strong>Total Price:</strong> ₹{order.totalPrice}</p>
                <p><strong>Ordered At:</strong> {new Date(order.time || order.createdAt).toLocaleString()}</p>

                <select
                  value={order.status}
                  onChange={(e) => updateOrderStatus(order._id, e.target.value)}
                  style={{ padding: "5px", borderRadius: "4px", marginTop: "8px" }}
                >
                  <option value="Pending">Pending</option>
                  <option value="Preparing">Preparing</option>
                  <option value="Out for Delivery">Out for Delivery</option>
                  <option value="Delivered">Delivered</option>
                </select>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default UserOrders;
