import React, { useEffect, useState } from "react";
import api from "../api/axios";
import './Favorites.css';


const Favorites = () => {
  const [favorites, setFavorites] = useState([]);

  useEffect(() => {
    const fetchFavorites = async () => {
      try {
        const res = await api.get("/favorites/my-favorites");
        setFavorites(res.data.favorites);
      } catch (err) {
        console.error("Error fetching favorites:", err);
      }
    };
    fetchFavorites();
  }, []);

  const removeFavorite = async (id) => {
    try {
      await api.delete(/favorites/`${id}`);
      setFavorites(favorites.filter((fav) => fav._id !== id));
    } catch (err) {
      console.error("Error removing favorite:", err);
    }
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>My Favorites ❤</h2>
      {favorites.length === 0 ? (
        <p>No favorites yet. Add some food from Menu!</p>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: "20px" }}>
          {favorites.map((fav) => (
            <div key={fav._id} style={{ border: "1px solid #ccc", padding: "15px", borderRadius: "8px" }}>
              <h3>{fav.foodId.name}</h3>
              <p>₹{fav.foodId.price}</p>
              <button 
                onClick={() => removeFavorite(fav._id)} 
                style={{ background: "red", color: "white", padding: "5px 10px", borderRadius: "5px", border: "none", cursor: "pointer" }}
              >
                Remove ❌
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Favorites;