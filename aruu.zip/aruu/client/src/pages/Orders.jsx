import React, { useEffect, useState } from "react";
import axios from "axios";
import "./Orders.css"; // Optional: add styling as needed

const Orders = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/orders");
      setOrders(res.data);
    } catch (err) {
      console.error("Error fetching orders:", err);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleString(); // Local time and date
  };

  return (
    <div className="orders-container">
      <h2>📋 All Orders</h2>
      {loading ? (
        <p>Loading orders...</p>
      ) : orders.length === 0 ? (
        <p>No orders yet.</p>
      ) : (
        orders.map((order) => (
          <div key={order._id} className="order-card">
            <p><strong>📧 Email:</strong> {order.email}</p>
            <p><strong>🕒 Time:</strong> {formatDate(order.time)}</p>
            <p><strong>💰 Total Price:</strong> ₹{order.totalPrice}</p>
            <p><strong>🚚 Status:</strong> {order.status}</p>

            <div className="order-items">
              {order.items.map((item, idx) => (
                <div key={idx} className="order-item">
                  <img
                    src={item.image}
                    alt={item.foodName}
                    className="order-item-img"
                  />
                  <div>
                    <p><strong>{item.foodName}</strong></p>
                    <p>Qty: {item.quantity}</p>
                    <p>Price: ₹{item.totalPrice}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))
      )}
    </div>
  );
};

export default Orders;