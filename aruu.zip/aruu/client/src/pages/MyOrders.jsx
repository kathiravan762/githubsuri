import React, { useEffect, useState } from "react";
import api from '../api/axios';  // axios.js with baseURL + token
import './MyOrders.css'; // Add your styles here

const MyOrders = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
      const token = localStorage.getItem("token");
  if (!token) {
    console.log("No token, cannot fetch orders");
    return;
  }

    const fetchOrders = async () => {
      try {
        // correct API call (GET /api/orders/my-orders)
        const res = await api.get("/orders/my-orders");
        setOrders(res.data.orders || []);
      } catch (err) {
        console.error("Error fetching orders:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchOrders();
  }, []);

  if (loading) return <p>Loading orders...</p>;

  return (
    <div className="orders-container">
      <h2 className="orders-title">📦 My Orders</h2>

      {orders.length === 0 ? (
        <p className="empty-msg">No orders found.</p>

      ) : (
         <div className="orders-list">

        <ul>
          {orders.map((order) => (
             <div className="order-card" key={order._id}>

            <li key={order._id} style={{ marginBottom: "10px" }}>
              <p><strong>Order ID:</strong> {order._id}</p>
              <p><strong>Email:</strong> {order.email || 'N/A'}</p>
               <p><strong>Ordered At:</strong> {new Date(order.time).toLocaleString()}</p>
              
              <p><strong>Status:</strong> {order.status}</p>
              <p><strong>Total:</strong> ₹{order.totalPrice}</p>
              <p><strong>Items:</strong></p>
              <ul>
                {order.items.map((item, idx) => (
                  <li key={idx}>
                    {item.foodName} × {item.quantity} = ₹{item.total}
                  </li>
                ))}
              </ul>
              
              <hr />
            </li>
             </div>

          ))}
        </ul>
         </div>

      )}
    </div>
  );
};

export default MyOrders;