import React, { useState, useEffect } from 'react';
import { FaArrowLeft, FaArrowRight } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';
import './Home.css';
import { Link } from 'react-router-dom';
const images = [
  '/assets/food1.jpg',
  '/assets/food2.jpg',
  '/assets/food3.jpg',
  '/assets/food4.jpg'
];

const Home = () => {
  const navigate = useNavigate();
  const [index, setIndex] = useState(0);

  const nextSlide = () => {
    setIndex((prev) => (prev + 1) % images.length);
  };
  const handleOfferClick = () => {
    const user = JSON.parse(localStorage.getItem("user"));
    if (user) {
      navigate("/offer");
    } else {
      alert("⚠ Please login to view today's offers.");
    }
  };

  const prevSlide = () => {
    setIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  useEffect(() => {
    const interval = setInterval(() => {
      nextSlide();
    }, 2000); // auto change every 2 sec
    return () => clearInterval(interval);
  }, []);

  return (

    <div className='page'>
       <div className="slider">
      {images.map((img, i) => (
        <img
          key={i}
          src={img}
          alt={`slide-${i}`}
          className={`slide-image ${i === index ? 'active' : ''}`}
        />
      ))}
      <FaArrowLeft className="arrow arrow-left" onClick={prevSlide} />
      <FaArrowRight className="arrow arrow-right" onClick={nextSlide} />
      
    </div >
    <div className="welc">
      <div className="content">
        <h1>Welcome to Foodie Haven</h1>
        <p>Your one-stop destination for delicious food recipes and reviews.</p>
        <p>Explore our collection of mouth-watering dishes and share your feedback!</p>
        </div>
            <div className='offer' onClick={handleOfferClick} style={{ cursor: 'pointer' }}>

        <img src="https://www.shutterstock.com/image-vector/black-friday-sale-banner-speech-600nw-2527890405.jpg" id='imag' />
        </div>
        </div>
   <div className="special-section">
  <img src="https://png.pngtree.com/background/20210715/original/pngtree-special-offer-big-discount-for-black-friday-sale-background-with-trolley-picture-image_1258702.jpg" alt="Black Friday Sale" className="special-image" />

  <div className="special-text">
    <h1>Special Offers</h1>
    <p>Don't miss out on our exclusive deals and discounts!</p>
    <p>Check back often for the latest offers.</p>
  </div>
  
</div> 
<div className='Home-page' style={{ textAlign: 'center', marginTop: '2rem' }}>
       <Link to="/menu" className="back-home-btn">Explore Our Menu</Link>
       </div>
    </div>
  );
};
export default Home;