import React, { useState } from "react";
import "./ContectUs.css";

const ContactUs = () => {
  const [formData, setFormData] = useState({ name: "", email: "", message: "" });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Your message has been submitted. Thank you!");
    setFormData({ name: "", email: "", message: "" });
  };

  return (
    <div className="contact-page">
      <div className="contact-header">
        <h1>Contact Us</h1>
        <p>We’d love to hear from you! Get in touch for any queries, feedback, or support.</p>
      </div>

      <div className="contact-info">
        <div className="info-box">
          <h2>📍 Address</h2>
          <p> East  Street,<br />Idaiyankudi ,<br />Tamil Nadu, India.</p>
        </div>

        <div className="info-box">
          <h2>📞 Phone</h2>
          <p>+91 98765 43210<br />+91 99444 22110</p>
        </div>

        <div className="info-box">
          <h2>✉️ Email</h2>
          <p>support@aruufoods.com<br />helpdesk@aruufoods.com</p>
        </div>

        <div className="info-box">
          <h2>🕒 Working Hours</h2>
          <p>Monday – Saturday: 9:00 AM – 8:00 PM<br />Sunday: Closed</p>
        </div>
      </div>

     

      <div className="map-section">
        <h2>Find Us on Map</h2>
        <iframe
          title="Aruu Foods Location"
          src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d246.74300176386575!2d77.88193764397482!3d8.313989638238386!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sin!4v1760182424336!5m2!1sen!2sin" 
          allowFullScreen=""
          loading="lazy"
        ></iframe>
      </div>
    </div>
  );
};

export default ContactUs;
