import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Feedback.css';
import { Link } from 'react-router-dom';

const Feedback = () => {
  const [rating, setRating] = useState(0);
  const [hover, setHover] = useState(0);
  const [comment, setComment] = useState('');
  const [feedbacks, setFeedbacks] = useState([]);

  const user = JSON.parse(localStorage.getItem('user'));

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/feedback', {
        email: user.email,
        rating,
        comment,
      });
      setComment('');
      setRating(0);
      fetchFeedbacks();
    } catch (err) {
      console.error('Error:', err);
    }
  };

  const fetchFeedbacks = async () => {
    const res = await axios.get('http://localhost:5000/api/feedback');
    setFeedbacks(res.data);
  };

  useEffect(() => {
    fetchFeedbacks();
  }, []);

  return (
    <div>
      <Link to="/grievience"  className="back-home-btn" style={{ marginLeft: "20px" }}> Grievience</Link>

    <div className="feedback-container">
      <h2>Give your Feedback ⭐</h2>
      <form onSubmit={handleSubmit}>
        <div className="star-rating">
          {[...Array(5)].map((star, index) => {
            index += 1;
            return (
              <button
                type="button"
                key={index}
                className={index <= (hover || rating) ? "on" : "off"}
                onClick={() => setRating(index)}
                onMouseEnter={() => setHover(index)}
                onMouseLeave={() => setHover(rating)}
              >
                ★
              </button>
            );
          })}
        </div>
        <textarea
          placeholder="Write your feedback..."
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          required
        ></textarea>
        <br />
        <button type="submit" className="submit-btn">Submit</button>
      </form>

      <div className="feedback-list">
        <h3>💬 Customer Feedback</h3>
        {feedbacks.map((fb, idx) => (
          <div className="feedback-item" key={idx}>
            <p><strong>{fb.email}</strong></p>
            <div className="rating">{'⭐'.repeat(fb.rating)}</div>
            <p>{fb.comment}</p>
          </div>
        ))}
      </div>
    </div>
    </div>
    
  );
};

export default Feedback;