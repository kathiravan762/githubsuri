import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { useContext } from 'react';
import { useCart } from '../context/CartContext';
import { toast } from 'react-toastify';
import './Menu.css'; // Assuming you have a CSS file for styling
import api from '../api/axios'; // Import your axios instance
import { Link } from 'react-router-dom';
const Menu = () => {
  const [foods, setFoods] = useState([]);
  const [quantities, setQuantities] = useState({});
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [search, setSearch] = useState("");
  const { addToCart } = useCart();
  const res = JSON.parse(localStorage.getItem("user"));



  useEffect(() => {
    // Fetch foods from backend
    axios.get('http://localhost:5000/api/food')
      .then((res) => {
        setFoods(res.data);

        const initialQuantities = {};
        res.data.forEach((food) => {
          initialQuantities[food._id] = 1;
        });
        setQuantities(initialQuantities);
      })
      .catch((err) => {
        console.error('Error fetching foods:', err);
      });

    // Check if admin is logged in
    const adminStatus = localStorage.getItem('isAdminLoggedIn');
    setIsAdminLoggedIn(adminStatus === 'true');
  }, []);

  const handleQuantityChange = (id, type) => {
    setQuantities((prev) => {
      const current = prev[id] || 1;
      const newQty = type === 'inc' ? current + 1 : Math.max(1, current - 1);
      return { ...prev, [id]: newQty };
    });
  };
  

 const addToFavorites = async (foodId) => {
    try {
      await api.post("/favorites/add", { foodId });
      alert("Added to favorites ❤");
    } catch (err) {
      console.error("Error adding favorite:", err);
    }
  };


const handleOrder = async (food) => {
  const emailInput = prompt("Enter your email:");
  if (!emailInput) return;

  try {
    // Step 1: Send OTP
    await axios.post("http://localhost:5000/api/otp/send-otp", { email: emailInput });

    // Step 2: Verify OTP
    const enteredOtp = prompt("Enter the OTP sent to your email:");
    if (!enteredOtp) return;

    const otpVerify = await axios.post("http://localhost:5000/api/otp/verify-otp", {
      email: emailInput,
      otp: enteredOtp,
    });

    if (!otpVerify.data.success) {
      toast.error("❌ Invalid OTP");
      return;
    }

    // Step 3: Ask address & phone
    const address = prompt("Enter your delivery address:");
    const phone = prompt("Enter your phone number:");

    const user = JSON.parse(localStorage.getItem("user"));
    const quantity = quantities[food._id] || 1;
    const totalPrice = food.price * quantity;

    const orderData = {
      userId: user._id || user.id,
      email: emailInput, // ✅ use emailInput instead of empty state
      address,           // ✅ now included
      phone,             // ✅ now included
      totalPrice,
      items: [
        {
          foodName: food.name,
          price: food.price,
          quantity,
          total: totalPrice,
          image: `http://localhost:5000/uploads/${food.image || food.imageFilename}`,
        },
      ],
    };

    console.log("Sending orderData:", orderData);

    const res = await api.post("/orders", orderData);
    if (res.status === 201) {
      alert("🎉 Order placed successfully!");
      window.location.href = "/orders";
    }
  } catch (err) {
    console.error("Order error:", err?.response?.data || err.message);
    alert(err?.response?.data?.error || "Failed to place order.");
  }
};

    const handleLogout = () => {
  localStorage.removeItem('isAdminLoggedIn');
  window.location.href = '/adminlogin'; // or use navigate('/adminlogin');
};

  return (
    <div className="menu-page" style={{ padding: '20px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        
        <h2 style={{color:'#cc5800'}}>Our Menu  </h2>
<input 
  type="text"
  placeholder="Search food..."
  className='SEFL'
  onChange={(e) => setSearch(e.target.value)}
/>-  <Link to="/favorites" className="back-home-btn">favorite</Link>
      {isAdminLoggedIn && (
  <button onClick={() => navigate('/admin')} className="admin-button">
    Admin Panel
  </button>
 
)}
      </div>
<div>
    {isAdminLoggedIn && (
      <button onClick={handleLogout} style={{ marginLeft: '20px', padding: '10px 15px', background: '#dc3545', color: '#fff', border: 'none', borderRadius: '5px' }}>
        Logout
      </button>
    )}

</div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '20px', marginTop: '20px' }}>
      {foods
  .filter((food) =>
    food.name.toLowerCase().includes(search.toLowerCase())
  )
  .map((food) => (
          <div
            key={food._id}
            style={{
              border: '1px solid #ccc',
              padding: '15px',
              borderRadius: '10px',
              width: '250px',
              textAlign: 'center',
              background: '#f9f9f9',
              boxShadow: '0 2px 6px rgba(0,0,0,0.1)',
            }}
          >
            <img
              src={`http://localhost:5000/uploads/${food.image}`}
              alt={food.name}
              style={{ width: '100%', height: '160px', objectFit: 'cover', borderRadius: '8px' }}
            />
            <h3>{food.name}</h3>
            <p>₹ {food.price}</p>
            <p>{food.description}</p>
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '10px', margin: '10px 0' }}>
              <button onClick={() => handleQuantityChange(food._id, 'dec')}>-</button>
              <span>{quantities[food._id]}</span>
              <button onClick={() => handleQuantityChange(food._id, 'inc')}>+</button>
            </div>
            <button
              onClick={() => handleOrder(food)}
              style={{ padding: '6px 12px', background: '#28a745', color: '#fff', border: 'none', borderRadius: '5px' }}
            >
              Order
            </button>
           <button
  onClick={() => {
    addToCart({
      _id: food._id,
      name: food.name,
      price: food.price,
      image: food.image,
      quantity: quantities[food._id] || 1,
    });
    alert(`${food.name} added to cart!`);
  }}style={{ padding: '6px 12px', background: '#c1be11ff', color: '#fff', border: 'none', borderRadius: '5px' }}
>
  Cart
</button>
   <button 
              onClick={() => addToFavorites(food._id)} 
              style={{ fontSize: "20px", background: "none", border: "none", cursor: "pointer", color: "red" }}
            >
              ❤
            </button>

          </div>
        ))}
      </div>
    </div>
  );
};

export default Menu;