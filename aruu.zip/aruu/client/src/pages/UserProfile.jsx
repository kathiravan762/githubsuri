import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './UserProfile.css'; // Assuming you have a CSS file for styling

const UserProfile = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState({});
  const [editMode, setEditMode] = useState(false);
  const [updatedName, setUpdatedName] = useState('');
  const [updatedPassword, setUpdatedPassword] = useState('');

  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem('user'));
    if (storedUser) {
      setUser(storedUser);
      setUpdatedName(storedUser.name);
    } else {
      navigate('/login'); // If user not logged in
    }
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('user');
    navigate('/login');
    // Logout function
  localStorage.removeItem("token"); // token remove pannum
  window.location.href = "/login";  // login page ku redirect pannum

  };

  const handleDelete = async () => {
    try {
      const confirm = window.confirm('Are you sure you want to delete your account?');
      if (!confirm) return;

      await axios.delete('http://localhost:5000/api/user/delete', {
        data: { email: user.email },
      });

      localStorage.removeItem('user');
      navigate('/login');
    } catch (err) {
      console.error('Delete failed:', err);
    }
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.put('http://localhost:5000/api/user/update', {
        email: user.email,
        name: updatedName,
        password: updatedPassword,
      });

      if (res.data.success) {
        localStorage.setItem('user', JSON.stringify(res.data.user));
        setUser(res.data.user);
        setEditMode(false);
        alert('Profile updated successfully');
      }
    } catch (err) {
      console.error('Update failed:', err);
    }
  };
  

  return (
    <div style={{ maxWidth: '500px', margin: 'auto', padding: '20px' }}>
      <h2>User Profile</h2>

      {editMode ? (
        <form onSubmit={handleUpdate}>
          <label>Name:</label><br />
          <input
            type="text"
            value={updatedName}
            onChange={(e) => setUpdatedName(e.target.value)}
            required
          /><br /><br />

          <label>New Password:</label><br />
          <input
            type="password"
            onChange={(e) => setUpdatedPassword(e.target.value)}
            required
          /><br /><br />

          <button type="submit">Save</button>
          <button type="button" onClick={() => setEditMode(false)} style={{ marginLeft: '2px' }}>
            Cancel
          </button>
        </form>
      ) : (
        <>
          <p><strong>Name:</strong> {user.name}</p>
          <p><strong>Email:</strong> {user.email}</p>
          <button onClick={() => setEditMode(true)}>Edit Profile</button>
        </>
      )}

      <br /><br />
      <button onClick={handleLogout}>Logout</button><br /><br />
      <button onClick={handleDelete} style={{ color: 'red' }}>Delete Account</button>
    </div>
  );
};

export default UserProfile;