
import { useCart } from '../context/CartContext';
import React, { useContext, useState } from "react";
import axios from "axios";
import { toast } from "react-toastify";
import './Cart.css'; 
import api from '../api/axios'; 

const Cart = () => {
  
  const { cartItems, removeFromCart, clearCart } = useCart();
  const [email, setEmail] = useState("");

  const totalPrice = cartItems.reduce(
    (total, item) => total + item.price * item.quantity,
    0
  );

const handlePlaceOrder = async () => {
  const emailInput = prompt("Enter your email:");
  if (!emailInput) return;

  const addressInput = prompt("Enter your delivery address:");
  if (!addressInput) return;

  const phoneInput = prompt("Enter your phone number:");
  if (!phoneInput) return;

  try {
    const items = cartItems.map((item) => ({
      foodName: item.name,
      image: `http://localhost:5000/uploads/${item.image}`,
      price: item.price,
      quantity: item.quantity,
      totalPrice: item.price * item.quantity,
    }));

    const orderPayload = {
      userId: localStorage.getItem("userId"), // ✅ send logged-in user's ID
      email: emailInput,
      address: addressInput,
      phone: phoneInput,
      items,
      totalPrice,
    };

    const response = await api.post("/orders", orderPayload);

    if (response.status === 201) {
      toast.success("✅ Order placed successfully!");
      clearCart();
      localStorage.removeItem("cartItems");
    } else {
      toast.error("❌ Order failed. Try again.");
    }
  } catch (error) {
    console.error("Order Error:", error.response?.data || error.message);
    toast.error("⚠ Something went wrong while placing the order.");
  }
};

  return (
    <div className="cart-container">
      <h2 className="cart-title">🛒 Your Cart</h2>
      {cartItems.length === 0 ? (
        <p className="empty-cart-message">Your cart is empty.</p>
      ) : (
        <div className="space-y-4">
          {cartItems.map((item) => (
            <div
              key={item._id}
              className="cart-item"
            >
              <div className="flex items-center">
                     <img
        src={`http://localhost:5000/uploads/${item.image}`}
        alt={item.name}
        className="cart-item-img"
      />
                <div>
                  <h3 className="cart-item-info">{item.name}</h3>
                  <p>
                    ₹{item.price} × {item.quantity}
                  </p>
                  <p className="text-green-600">
                    Total: ₹{item.price * item.quantity}
                  </p>
                </div>
              </div>
              <button
                className="remove-button"
                onClick={() => removeFromCart(item._id)}
              >
                Remove
              </button>
            </div>
          ))}
          <div className="cart-total-box">
            <h4 className="total-price">
              🧾 Total Price: ₹{totalPrice}
            </h4>
          
            <button
              onClick={handlePlaceOrder}
              className="place-order-btn"
            >
              Place Order
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Cart;