import React, { useEffect, useState } from "react";
import axios from "../api/axios";
import "./ViewGrievience.css";

const ViewGrievience = () => {
  const [grievances, setGrievances] = useState([]);

  useEffect(() => {
    axios.get("/grievience").then((res) => setGrievances(res.data));
  }, []);

  return (
    <div className="view-griev">
      <h1>Grievience Records</h1>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Message</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
          {grievances.map((g) => (
            <tr key={g._id}>
              <td>{g.name}</td>
              <td>{g.email}</td>
              <td>{g.message}</td>
              <td>{new Date(g.createdAt).toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ViewGrievience;
