import React, { useState } from "react";
import axios from "../api/axios";
import "./SubmitGrievience.css";

const SubmitGrievience = () => {
  const [formData, setFormData] = useState({ name: "", email: "", message: "" });
  const [status, setStatus] = useState("");

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post("/grievience", formData);
      setStatus("✅ Grievience submitted successfully!");
      setFormData({ name: "", email: "", message: "" });
    } catch (err) {
      setStatus("❌ Error submitting grievance. Try again.");
    }
  };

  return (
    <div className="griev-form">
      <h1>Submit Grievience</h1>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="name"
          placeholder="Your Name"
          value={formData.name}
          onChange={handleChange}
          required
        />
        <input
          type="email"
          name="email"
          placeholder="Your Email"
          value={formData.email}
          onChange={handleChange}
          required
        />
        <textarea
          name="message"
          placeholder="Describe your issue..."
          value={formData.message}
          onChange={handleChange}
          required
        ></textarea>
        <button type="submit">Submit</button>
      </form>
      {status && <p className="status-msg">{status}</p>}
    </div>
  );
};

export default SubmitGrievience;
