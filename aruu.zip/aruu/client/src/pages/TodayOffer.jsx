// src/pages/TodayOffer.jsx

import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './TodayOffer.css';
import api from '../api/axios';
const TodayOffer = () => {
  const [offerItems, setOfferItems] = useState([]);
  const [quantities, setQuantities] = useState({});

  useEffect(() => {
    fetchOffers();
  }, []);

  const fetchOffers = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/offer/all');
      setOfferItems(res.data.offers); // ✅ FIXED: use .offers
    } catch (err) {
      console.error('Error fetching offers:', err);
    }
  };

  const updateQuantity = (id, delta) => {
    setQuantities((prev) => ({
      ...prev,
      [id]: Math.max((prev[id] || 1) + delta, 1),
    }));
  };

  const handleOrder = async (item) => {
    const email = prompt("Enter your email:");
    if (!email) return;

    try {
      await axios.post('http://localhost:5000/api/otp/send-otp', { email });

      const enteredOtp = prompt("Enter the OTP sent to your email:");
      if (!enteredOtp) return;

      const otpRes = await axios.post('http://localhost:5000/api/otp/verify-otp', {
        email,
        otp: enteredOtp
      });

      if (!otpRes.data.success) {
        alert("Invalid OTP");
        return;
      }

      const quantity = quantities[item._id] || 1;
      const totalPrice = item.price * quantity;

      const orderData = {
        email,
        name: item.name,
        price: item.price,
        quantity,
        totalPrice,
        image: item.image,
        items: [
          {
            foodName: item.name,
            price: item.price,
            quantity,
            totalPrice,
            image: item.image,
          },
        ],
      };

         const res = await api.post('/orders', orderData);
    
      if (res.status === 201) {
        alert("🎉 Order placed successfully!");
        window.location.href = '/orders'; // ✅ redirect
      } else {
        alert("Order failed.");
      }

    } catch (err) {
      console.error("Order error:", err);
      alert("Order failed. Try again.");
    }
  };

  return (
    <div className="offer-container">
      <h2 className="offer-title">🔥 Today's Special Offers</h2>
      <div className="offer-grid">
        {offerItems.map((item) => (
          <div className="offer-card" key={item._id}>
            <img src={`http://localhost:5000/${item.image}`} alt={item.name} className="offer-img" />
            <h3>{item.name}</h3>
            <p>Price: ₹{item.price}</p>
            <div className="quantity-control">
              <button onClick={() => updateQuantity(item._id, -1)}>-</button>
              <span>{quantities[item._id] || 1}</span>
              <button onClick={() => updateQuantity(item._id, 1)}>+</button>
            </div>
            <button className="order-btn" onClick={() => handleOrder(item)}>Order</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TodayOffer;