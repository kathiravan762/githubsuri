import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import './Admin.css';

const Admin = () => {
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [description, setDescription] = useState('');
  const [isAvailable, setIsAvailable] = useState(true);
  const [image, setImage] = useState(null);
  const [foodList, setFoodList] = useState([]);
  const [orderList, setOrderList] = useState([]);

  useEffect(() => {
    fetchFoods();
    fetchOrders();
  }, []);
  const updateOrderStatus = async (orderId, newStatus) => {
  try {
    await axios.put(`http://localhost:5000/api/order/update-status/${orderId}`, {
      status: newStatus
    });
    // reload orders
  } catch (err) {
    console.error('Status update failed', err);
  }
};

  const fetchFoods = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/food');
      setFoodList(res.data);
    } catch (err) {
      console.error('Error fetching foods:', err);
    }
  };

  const fetchOrders = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/orders');
      setOrderList(res.data);
    } catch (err) {
      console.error('Error fetching orders:', err);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!name || !price || !image) {
      alert('Name, price, and image are required.');
      return;
    }

    const formData = new FormData();
    formData.append('name', name);
    formData.append('price', price);
    formData.append('description', description);
    formData.append('isAvailable', isAvailable);
    formData.append('image', image);

    try {
      await axios.post('http://localhost:5000/api/food/add', formData);
      alert('Food added successfully');
      fetchFoods();
      setName('');
      setPrice('');
      setDescription('');
      setIsAvailable(true);
      setImage(null);
    } catch (err) {
      console.error('Add food error:', err);
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/food/${id}`);
      fetchFoods();
    } catch (err) {
      console.error('Delete error:', err);
    }
  };

  return (
    <div className='admin-container'>
      <div style={{ padding: '20px' }}>
      <div className='aa' > <Link to="/addoffer">Add Offer</Link></div>
       <div className='aa' > <Link to="/userorders"> User orders</Link></div>
       <Link to="/admin/grievience">View Grievience</Link>

        <h2>Admin Panel - Add Food</h2>
         
        <form onSubmit={handleSubmit} style={{ marginBottom: '30px' }}>
          <input
            type="text"
            placeholder="Food Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          /><br /><br />

          <input
            type="number"
            placeholder="Price"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            required
          /><br /><br />

          <textarea
            placeholder="Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          /><br /><br />

          <label>
            Available?{' '}
            <input
              type="checkbox"
              checked={isAvailable}
              onChange={() => setIsAvailable(!isAvailable)}
            />
          </label><br /><br />

          <input
            type="file"
            onChange={(e) => setImage(e.target.files[0])}
            accept="image/*"
            required
          /><br /><br />

          <button type="submit">Add Food</button>
           
        </form>

        {/* ------------ Food List ------------ */}
        <h3>Food List</h3>
        <div className='food-list' style={{ display: 'flex', flexWrap: 'wrap', gap: '20px' }}>
          {foodList.map((food) => (
            <div
              key={food._id}
              style={{
                border: '1px solid #ccc',
                padding: '10px',
                width: '200px',
                borderRadius: '10px',
                textAlign: 'center'
              }}
            >
              <img
                src={`http://localhost:5000/uploads/${food.image}`}
                alt={food.name}
                style={{ width: '100%', height: '120px', objectFit: 'cover', borderRadius: '8px' }}
              />
              <h4>{food.name}</h4>
              <p>₹ {food.price}</p>
              <p style={{ fontSize: '13px' }}>{food.description}</p>
              <p>Status: {food.isAvailable ? 'Available' : 'Not Available'}</p>
              <button
                onClick={() => handleDelete(food._id)}
                style={{ background: 'red', color: '#fff', border: 'none', padding: '6px 12px', borderRadius: '6px' }}
              >
                Delete
              </button>
            </div>
          ))}
        </div>

        {/* ------------ Order List ------------ */}
        <h3 style={{ marginTop: '40px' }}>User Orders</h3>
        <div className='order-list'>
          {orderList.length === 0 ? (
            <p>No orders yet.</p>
          ) : (
            <div style={{ marginTop: '10px' }}>
              {orderList.map((order, index) => (
                <div key={index} style={{
                  background: '#f8f8f8',
                  padding: '10px',
                  marginBottom: '10px',
                  borderRadius: '6px',
                  boxShadow: '0 0 5px rgba(0,0,0,0.1)'
                }}>
                  <p><strong>Food:</strong> {order.foodName}</p>
                  <p><strong>Quantity:</strong> {order.quantity}</p>
                  <p><strong>Email:</strong> {order.email}</p>
                  <p><strong>Total Price:</strong> ₹ {order.totalPrice}</p>
                  <p>
                    <strong>Image:</strong>{' '}
                    <img
                      src={`http://localhost:5000/uploads/${order.image}`}
                      alt={order.foodName}
                      style={{ width: '50px', height: '50px', borderRadius: '4px' }}
                      onError={(e) => e.target.style.display = 'none'}
                    />
                  </p>
                  <p><strong>Ordered At:</strong> {new Date(order.time || order.createdAt).toLocaleString()}</p>
                  <select
  value={order.status}
  onChange={(e) => updateOrderStatus(order._id, e.target.value)}
>
  <option>Pending</option>
  <option>Preparing</option>
  <option>Out for Delivery</option>
  <option>Delivered</option>
</select>
                </div>
                
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Admin;