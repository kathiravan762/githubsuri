import React from 'react';
import './About.css';
import { Link } from 'react-router-dom';
import { useNavigate } from "react-router-dom";

const About = () => {
    const navigate = useNavigate();
  return (
    <div className="about-page">
      <h1>Welcome to Foodie Haven</h1>

      <section>
        <h2>Our Story</h2>
        <p>
          At Foodie Haven, we believe that great food brings people together. Founded with a passion for authentic taste and quality service, we are proud to serve delicious meals made from fresh ingredients, crafted with care and love.
        </p>
        <p>
          Whether you’re craving classic comfort food or something new and exciting, our diverse menu offers something for every palate. Our chefs work tirelessly to ensure each dish not only satisfies your hunger but also delights your taste buds.
        </p>
      </section>

      <section>
        <h2>What We Offer</h2>
        <ul>
          <li>Wide variety of freshly prepared dishes</li>
          <li>Easy and secure online ordering experience</li>
          <li>Quick delivery with real-time order tracking</li>
          <li>Daily specials and customer favorites</li>
          <li>Hygienic preparation and eco-friendly packaging</li>
        </ul>
      </section>

      <section>
        <h2>Why Choose Us?</h2>
        <p>
          Foodie Haven stands for quality, consistency, and convenience. We aim to provide a seamless food ordering experience — from browsing our menu to receiving your meal at your doorstep. We value your trust and strive to exceed your expectations every single time.
        </p>
      </section>

      <section>
        <h2>Join the Foodie Family</h2>
        <p>
          We're more than just a food service — we're a community of food lovers. Stay updated with our latest offers, new menu items, and exclusive discounts by signing up. We’re excited to serve you!
        </p>
      </section>

      <div style={{ textAlign: 'center', marginTop: '2rem' }}>
        
        <Link to="/help" className="back-home-btn" style={{ marginLeft: "20px" }}>
  Help Center
</Link>
 <div className="about-page">
      {/* your existing content */}
      <button 
        className="contact-btn"
        onClick={() => navigate("/contact")}
      >
        Contact Us
      </button>
    </div>

      </div>
    </div>
  );
};

export default About;