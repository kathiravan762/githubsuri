import React, { useState } from 'react';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';
import './Adminlogin.css'; // Custom CSS file

const AdminLogin = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    
    try {
      const res = await axios.post('http://localhost:5000/api/admin/login', {
        username,
        password
      });

      if (res.data.success) {
        localStorage.setItem('isAdminLoggedIn', 'true');
        sessionStorage.setItem('adminDetails', JSON.stringify(res.data.admin));
        navigate('/admin');
      } else {
        setErrorMsg('Invalid credentials');
      }
    } catch (err) {
      console.error('Login error:', err);
      setErrorMsg('Login failed. Please try again.');
    }
  };

  return (
    <div className='login-container'>
      <div className='login-box'>
        <h2>Admin Login</h2>
        <form onSubmit={handleLogin}>
          <input
            type="text"
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          /><br /><br />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          /><br /><br />
          <button type="submit">Login</button>
        </form>

        {errorMsg && <p style={{ color: 'red' }}>{errorMsg}</p>}

        <p className='login-switch'>
          
     
        <Link to="/User-login">Login as User</Link>
           </p>
      </div>
    </div>
  );
};

export default AdminLogin;