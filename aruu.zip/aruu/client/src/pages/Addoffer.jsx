// src/pages/AddOffer.jsx

import React, { useState } from 'react';
import axios from 'axios';

const AddOffer = () => {
  const [name, setName] = useState('');
  const [image, setImage] = useState('');
  const [price, setPrice] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/offer/add', {
        name,
        image,
        price,
      });
      alert("✅ Offer Added!");
      setName('');
      setImage('');
      setPrice('');
    } catch (err) {
      alert("❌ Error adding offer");
      console.log(err);
    }
  };

  return (
    <div style={{ textAlign: 'center', padding: '20px' }}>
      <h2>Add New Offer</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Food Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        /><br /><br />
        <input
          type="text"
          placeholder="Image Path (e.g., uploads/burger.jpg)"
          value={image}
          onChange={(e) => setImage(e.target.value)}
          required
        /><br /><br />
        <input
          type="number"
          placeholder="Price"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
          required
        /><br /><br />
        <button type="submit">Add Offer</button>
      </form>
    </div>
  );
};

export default AddOffer;