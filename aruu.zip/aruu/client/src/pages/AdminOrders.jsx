
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const AdminOrders = () => {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/order');
      setOrders(res.data);
    } catch (err) {
      console.error('Error fetching orders:', err);
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>User Orders</h2>
      <div style={{ backgroundColor: '#f4f4f4', padding: '20px', borderRadius: '10px' }}>
        {orders.length === 0 ? (
          <p>No orders yet.</p>
        ) : (
          orders.map((order, index) => (
            <div
              key={index}
              style={{
                marginBottom: '20px',
                background: '#fff',
                padding: '15px',
                borderRadius: '10px',
                boxShadow: '0 2px 5px rgba(0,0,0,0.1)'
              }}
            >
            <p><strong>Food:</strong> {order.foodName}</p>
    <p><strong>Quantity:</strong> {order.quantity}</p>
    <p><strong>Email:</strong> {order.email || 'N/A'}</p>
    <p><strong>Total Price:</strong> ₹ {order.totalPrice || (order.price * order.quantity)}</p>
    <p><strong>Image:</strong><br />
      <img
        src={`http://localhost:5000/uploads/${order.image}`}
        alt="Food"
        style={{ width: '150px', height: '100px', objectFit: 'cover', borderRadius: '8px' }}
      />
    </p>
    <p><strong>Ordered At:</strong> {new Date(order.time).toLocaleString()}</p>

              {order.image && (
                <img
                  src={`http://localhost:5000/uploads/${order.image}`}
                  alt={order.foodName}
                  style={{ width: '100px', height: '100px', borderRadius: '8px' }}
                />
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default AdminOrders;