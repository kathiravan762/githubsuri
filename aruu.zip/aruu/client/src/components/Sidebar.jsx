import React from 'react';

const Sidebar = () => (
  <div className="sidebr mobile-only">
  
  </div>
);

export default Sidebar;
