import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FaBars } from 'react-icons/fa'; // For hamburger icon

const Navbar = ({user}) => {
  const localUser = JSON.parse(localStorage.getItem('user'));
  const activeUser = user || localUser;
  const [showSidebar, setShowSidebar] = useState(false);
  const userDetails = sessionStorage.getItem('userdetails') || null;

  const toggleSidebar = () => {
    setShowSidebar(!showSidebar);
  };
  const logOut = () => {
    localStorage.removeItem('isAdmin');
    sessionStorage.removeItem('userdetails');
    window.location.href = '/login'; // Redirect to login page
  }

  return (
    <>
      <nav className="navbar">
        <h2>MSK FOOD ORDERING </h2>

        <div className="nav-links desktop-only">
         
          <Link to="/">Home</Link>
          <Link to="/about">About</Link>
          <Link to="/menu">Menu</Link>
       
         { /*<Link to="/orders">Orders</Link>*/}
          {/* <Link to="/admin">Dashboard</Link> */}
          <Link to="/my-orders">Orders</Link>
          <Link to="/cart">Cart</Link>
         
          <Link to="/feedback">Feedback</Link>
          {activeUser ? (
            <Link to="/profile"> 👤{activeUser.name}</Link>
          ) : (
          <Link to="/login">Login</Link>)}
        </div>

        {/* Mobile Menu Icon */}
        <div className="mobile-menu-icon mobile-only" onClick={toggleSidebar}>
          <FaBars size={24} />
        </div>
      </nav>

      {/* Sidebar Toggle for Mobile */}
      {showSidebar && (
        <div className="sidebar mobile-only">
          <ul>
             <Link to="/about">About</Link>
      
          </ul>
        </div>
      )}
    </>
  );
};

export default Navbar;
