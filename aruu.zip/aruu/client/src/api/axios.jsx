import axios from "axios";

// Backend base URL (local or deployed)
// Local: http://localhost:5000/api
// Deployed: https://your-backend-url.com/api
const api = axios.create({
  baseURL: import.meta.env.VITE_BACKEND_URL || "http://localhost:5000/api",
  headers: {
    "Content-Type": "application/json",
  },
});

// Interceptor: automatically attach JWT token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("token");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
      console.log("🔑 Sending token:", token.substring(0, 20) + "..."); // debug
    } else {
      console.log("⚠ No token found in localStorage");
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Interceptor: handle response errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      console.warn("⚠ Unauthorized! Redirecting to login...");
      localStorage.removeItem("token");
      window.location.href = "/login"; // force logout
    }
    return Promise.reject(error);
  }
);

export default api;