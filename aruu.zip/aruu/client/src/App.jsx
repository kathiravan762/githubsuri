import React,{ useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './components/navbar';
import Sidebar from './components/Sidebar';
import Home from './pages/home';
import About from './pages/about';
import AdminLogin from './pages/Adminlogin'; 
import Admin from './pages/Admin';
import Menu from './pages/Menu';
import Orders from './pages/orders';
import Feedback from './pages/Feedback'; 
import AdminOrders from './pages/AdminOrders';
import Cart from './pages/Cart';
import UserLogin from './pages/UserLogin';
import UserRegister from './pages/UserRegister';
import TodayOffer from './pages/TodayOffer';
import AddOffer from './pages/Addoffer.jsx';
import MyOrders from './pages/MyOrders.jsx';
import Favorites from './pages/Favorites.jsx';
import UserOrders from './pages/userorders.jsx'; 
import HelpCenter from "./pages/HelpCenter";
import ContactUs from "./pages/ContectUs";
import SubmitGrievience from "./pages/SubmitGrievience";
import ViewGrievience from "./pages/ViewGrievience";



import './App.css';

import { CartProvider }from './context/CartContext.jsx';
import UserProfile from './pages/UserProfile.jsx';

const App = () => {
  const isAdmin = localStorage.getItem('isAdmin') === 'true';
  const [user, setUser] = useState(null); // null = not logged in

  return (
      <CartProvider>
    <Router>
      <Navbar user={user} />
      <Sidebar />
      <div className="main-content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/help" element={<HelpCenter />} />
          <Route path="/grievience" element={<SubmitGrievience />} />
<Route path="/admin/grievience" element={<ViewGrievience />} />


          <Route path="/about" element={<About />} />
          <Route path="/menu" element={<Menu />} />
          <Route path="/orders" element={<Orders />} />
          <Route path="/feedback" element={<Feedback />} />
          <Route path="/login" element={<AdminLogin />} />
          <Route path="/admin" element={<Admin/>} />
          <Route path="adminorders" element={<AdminOrders />} />
          <Route path='/User-login' element={<UserLogin setUser={setUser} />} />
          <Route path="/profile" element={<UserProfile/>} />
          <Route path="/register" element={<UserRegister />} />
          {/* <Route path="/admin" element={isAdmin ? <Admin /> : <AdminLogin />} /> */}
        <Route path='/my-orders'element={<MyOrders/>} />
            <Route path="/cart" element={<Cart />} />
            <Route path="/offer" element={<TodayOffer />} />
            <Route path="/addoffer" element={<AddOffer />} />
            <Route path='/favorites'element={<Favorites />} />
          <Route path='/userorders' element={<UserOrders/>} /> 
          
<Route path="/contact" element={<ContactUs />} />
        </Routes>
      </div>
    </Router>
    </CartProvider>
  );
};

export default App;