const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
require('dotenv').config();



// Import route files
const adminRoutes = require('./routes/adminroutes');
const userRoutes = require('./routes/userroutes'); // optional, if user management is in backend
const foodRoutes = require('./routes/foodroutes');
const orderRoutes = require('./routes/orderroutes');
const feedbackRoutes = require('./routes/feedbackroutes');
const offerRoutes = require('./routes/offerroutes'); // optional, if offers are managed in backend
const otpRoutes = require('./routes/otproutes');
const authRoutes = require('./routes/authroutes'); // Authentication routes
const jwt = require('jsonwebtoken');
const favoritesRoutes = require('./routes/favoritesroutes'); // Favorites management
const helpRoutes = require('./routes/helproutes');
const grievienceRoutes = require("./routes/grievienceroutes");



const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Static folder for uploaded images
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Connect to MongoDB Atlas
mongoose.connect('mongodb+srv://kathiravans762:1vsdUvfTwuELsYXn@kathiravan.estghsz.mongodb.net/?retryWrites=true&w=majority&appName=Kathiravan', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('✅ MongoDB connected successfully'))
.catch((err) => console.error('❌ MongoDB connection error:', err));

// Routes

app.use("/api/help", helpRoutes);

app.use("/api/grievience", grievienceRoutes);

app.use('/api/admin', adminRoutes);       // Admin login
app.use('/api/food', foodRoutes);         // Food add/view     
app.use('/api/feedback', feedbackRoutes); // Feedback (if needed)
app.use('/api/orders', orderRoutes); // Order management
app.use('/api/otp', otpRoutes);
app.use('/api/user',userRoutes)
app.use('/api/offer', offerRoutes); // Offers management (if needed)
app.use('/api/auth', authRoutes); // Authentication routes
app.use('/api/favorites', favoritesRoutes); // Favorites management
app.use(cors({ origin: 'http://localhost:5173', credentials: true }));
// Start server
const PORT = 5000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
