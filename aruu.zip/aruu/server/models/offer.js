const mongoose = require('mongoose');

const offerSchema = new mongoose.Schema({
  name: String,
  image: String,
  price: Number,
});

module.exports = mongoose.model('Offer', offerSchema);