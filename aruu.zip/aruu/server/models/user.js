const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  email: {
    type: String,
    required: true,
    unique: true, // prevents duplicate emails
    lowercase: true
  },
  password: {
    type: String,
    required: true
  },
  orders: [
    {
      items: [
        {
          foodName: String,
          quantity: Number,
          price: Number,
          image: String,
          totalPrice: Number
        }
      ],
      total: Number,
      date: {
        type: Date,
        default: Date.now
      }
    }
  ]
});

module.exports = mongoose.model('User', userSchema);