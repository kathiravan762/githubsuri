const nodemailer = require('nodemailer');

// Temporary in-memory OTP store
const otpStorage = {};

exports.sendOtp = async (req, res) => {
  const { email } = req.body;

  // Generate OTP
  const otp = Math.floor(100000 + Math.random() * 900000);
  otpStorage[email] = otp;

  // Nodemailer transporter
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'firestgaming@gmail.com',       // 🔁 Replace with your email
      pass: 'bmrtsqmjqgmugcem'           // 🔁 Use Gmail App Password
    }
  });

  // Mail content
  const mailOptions = {
     // user: 'firestgaming@gmail.com',       // 🔁 Replace with your email
    from: 'firestgaming@gmail.com',         // same as above
    to: email,
    subject: 'Your OTP for Food Order',
    text: `Your OTP is ${otp}`
  };

  try {
    await transporter.sendMail(mailOptions);
    res.status(200).json({ success: true, message: 'OTP sent successfully' });
  } catch (error) {
    console.error('Send OTP Error:', error);
    res.status(500).json({ success: false, message: 'Failed to send OTP' });
  }
};

exports.verifyOtp = (req, res) => {
  const { email, otp } = req.body;
  if (otpStorage[email] && otpStorage[email] == otp) {
    delete otpStorage[email]; // OTP used up
    res.status(200).json({ success: true, message: 'OTP verified successfully' });
  } else {
    res.status(400).json({ success: false, message: 'Invalid OTP' });
  }
};