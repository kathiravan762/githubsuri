const mongoose = require('mongoose');

const foodSchema = new mongoose.Schema({ name: String, image: String ,price : Number, description: String,  isAvailable: Boolean }, { timestamps: true });

module.exports = mongoose.model('Food', foodSchema);
