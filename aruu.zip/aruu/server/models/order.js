const mongoose = require('mongoose');

const itemSchema = new mongoose.Schema({
  foodName: String,
  image: String,
  price: Number,
  quantity: Number,
  totalPrice: Number
});

const orderSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User', // Links to User model
    required: true
  },
  email: {
    type: String,
    required: true
  },
  address: { type: String, required: true },   // ✅ add this
  phone: { type: String, required: true },
  items: [itemSchema],
  totalPrice: {
    type: Number,
    required: true
  },
  time: {
    type: Date,
    default: Date.now
  },
  status: {
    type: String,
    default: 'Pending'
  }
});

module.exports = mongoose.model('Order', orderSchema);