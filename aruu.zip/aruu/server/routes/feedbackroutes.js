const express = require('express');
const router = express.Router();
const Feedback = require('../models/feedback');

// POST feedback
router.post('/', async (req, res) => {
  const { email, rating, comment } = req.body;
  try {
    const fb = new Feedback({ email, rating, comment });
    await fb.save();
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false });
  }
});

// GET all feedbacks
router.get('/', async (req, res) => {
  const feedbacks = await Feedback.find().sort({ createdAt: -1 });
  res.json(feedbacks);
});

module.exports = router;