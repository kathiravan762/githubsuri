const express = require('express');
const router = express.Router();
const Food = require('../models/food');
const multer = require('multer');
const path = require('path');

// Image upload config
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ storage: storage });

// GET all foods
router.get('/', async (req, res) => {
  try {
    const foods = await Food.find();
    res.json(foods);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST add food
router.post('/add', upload.single('image'), async (req, res) => {
  try {
    const food = new Food({
      name: req.body.name,
      price: req.body.price,
      description: req.body.description,
      isAvailable: req.body.isAvailable,
      image: req.file.filename
    });

    await food.save();
    res.status(201).json({ success: true });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
});

// DELETE food
router.delete('/:id', async (req, res) => {
  try {
    await Food.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;