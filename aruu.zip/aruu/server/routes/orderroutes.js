const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth");
const Order = require("../models/order");
const nodemailer = require("nodemailer");

const adminEmail = process.env.ADMIN_EMAIL;

// ✅ Email Transporter Configuration
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER, // your Gmail
    pass: process.env.EMAIL_PASS, // App password (not your normal password)
  },
});

// ====================== PLACE ORDER (Requires Login) ======================
router.post("/", auth, async (req, res) => {
  try {
    const { items, email, totalPrice, address, phone } = req.body;

    // ✅ Basic validation
    if (!req.user.id || !email || !items || items.length === 0 || !totalPrice) {
      return res.status(400).json({ error: "All fields are required" });
    }

    // ✅ Create and Save Order
    const order = new Order({
      userId: req.user.id,
      items,
      email,
      totalPrice,
      address: address || "N/A",
      phone: phone || "N/A",
      time: new Date(),
      status: "Pending",
    });

    await order.save();

    // ✅ Send Admin Notification Email
    try {
      await transporter.sendMail({
        from: process.env.EMAIL_USER,
        to: adminEmail,
        subject: "📢 New Order Placed",
        html: `
          <h2>New Order Received</h2>
          <p><strong>Order ID:</strong> ${order._id}</p>
          <p><strong>User Email:</strong> ${email}</p>
          <p><strong>Total:</strong> ₹${totalPrice}</p>
          <h3>🛒 Ordered Items</h3>
          <ul>
            ${items
              .map(
                (item) =>
                  `<li>${item.foodName} × ${item.quantity} = ₹${
                    item.price * item.quantity
                  }</li>`
              )
              .join("")}
          </ul>
          <p><strong>Address:</strong> ${address || "Not Provided"}</p>
          <p><strong>Phone:</strong> ${phone || "Not Provided"}</p>
        `,
      });

      console.log("✅ Admin order email sent successfully");
    } catch (emailErr) {
      console.error("❌ Failed to send admin email:", emailErr);
    }

    res.status(201).json({
      message: "✅ Order placed successfully!",
      orderId: order._id,
    });
  } catch (error) {
    console.error("Order error:", error);
    res.status(500).json({ message: "Server error while placing order" });
  }
});

// ====================== GET MY ORDERS (Requires Login) ======================
router.get("/my-orders", auth, async (req, res) => {
  try {
    const orders = await Order.find({ userId: req.user.id }).sort({ time: -1 });
    res.json({ success: true, orders });
  } catch (e) {
    res
      .status(500)
      .json({ success: false, message: "Error fetching orders", error: e.message });
  }
});

// ====================== GET ALL ORDERS (Admin) ======================
router.get("/", async (req, res) => {
  try {
    const orders = await Order.find().sort({ time: -1 });
    res.json(orders);
  } catch (error) {
    res.status(500).json({ message: "Error fetching orders" });
  }
});

// ====================== UPDATE ORDER STATUS (Admin) ======================
router.put("/:id/status", async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  try {
    await Order.findByIdAndUpdate(id, { status });
    res.json({ message: "✅ Order status updated" });
  } catch (error) {
    res.status(500).json({ message: "Failed to update order status" });
  }
});

module.exports = router;
