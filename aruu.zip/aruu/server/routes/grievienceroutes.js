const express = require("express");
const router = express.Router();
const Grievience = require("../models/grievience");

// POST - create new grievance
router.post("/", async (req, res) => {
  try {
    const { name, email, message } = req.body;
    const newGrievience = new Grievience({ name, email, message });
    await newGrievience.save();
    res.status(201).json({ success: true, message: "Grievience submitted successfully" });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET - all grievances (for admin)
router.get("/", async (req, res) => {
  try {
    const grievances = await Grievience.find().sort({ createdAt: -1 });
    res.json(grievances);
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
