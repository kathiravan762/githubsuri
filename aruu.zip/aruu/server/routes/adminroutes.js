const express = require('express');
const router = express.Router();

// Dummy admin credentials (you can improve this with DB)
const ADMIN_USERNAME = 'admin';
const ADMIN_PASSWORD = '1234';

// POST /api/admin/login
router.post('/login', (req, res) => {
  const { username, password } = req.body;

  if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
    res.json({userDetails:req.body, success: true, });
    console.log("Admin login successful",req.body);
  } else {
    res.json({ success: false, });
  }
});

module.exports = router;