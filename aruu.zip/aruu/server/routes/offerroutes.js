// routes/offerroutes.js

const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');

const offerSchema = new mongoose.Schema({
  name: String,
  image: String,
  price: Number,
});

const Offer = mongoose.model('Offer', offerSchema);

// Add new offer
router.post('/add', async (req, res) => {
  const { name, image, price } = req.body;
  try {
    const newOffer = new Offer({ name, image, price });
    await newOffer.save();
    res.status(201).json({ success: true, message: 'Offer added' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error adding offer' });
  }
});

// Get all offers
router.get('/all', async (req, res) => {
  try {
    const offers = await Offer.find();
    res.json({ success: true, offers });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error fetching offers' });
  }
});

module.exports = router;