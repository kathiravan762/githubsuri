// routes/helpRoutes.js
const express = require("express");
const router = express.Router();
const nodemailer = require("nodemailer");

const adminEmail = process.env.ADMIN_EMAIL;

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// ================= SEND HELP REPORT =================
router.post("/", async (req, res) => {
  try {
    const { name, email, subject, message } = req.body;

    if (!name || !email || !subject || !message) {
      return res.status(400).json({ error: "All fields are required" });
    }

    // Email to admin
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: adminEmail,
      subject: `🆘 Help Request: ${subject}`,
      html: `
        <h3>New Help Request</h3>
        <p><b>Name:</b> ${name}</p>
        <p><b>Email:</b> ${email}</p>
        <p><b>Subject:</b> ${subject}</p>
        <p><b>Message:</b><br>${message}</p>
      `,
    };

    await transporter.sendMail(mailOptions);

    res.status(200).json({ success: true, message: "Help request sent to admin" });
  } catch (err) {
    console.error("Help request error:", err);
    res.status(500).json({ error: "Failed to send help request" });
  }
});

module.exports = router;
