const express = require('express');

const router = express.Router();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const User = require('../models/user');

// ----------------- SIGNUP -----------------
router.post('/signup', async (req, res) => {
  try {
    const { name, email, password } = req.body;

    // Check duplicate user
    let existing = await User.findOne({ email });
    if (existing) {
      console.log("⚠ Signup failed: Email already exists ->", email);
      return res.status(400).json({ message: 'Email already in use' });
    }

    // Hash password before saving
    const hashed = await bcrypt.hash(password, 10);

    const user = new User({ name, email, password: hashed });
    await user.save();

    console.log("✅ New user created:", email);
    res.status(201).json({ message: 'User created' });
  } catch (e) {
    console.error("🔥 Signup failed:", e.message);
    res.status(500).json({ message: 'Signup failed', error: e.message });
  }
});

// ----------------- LOGIN -----------------
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    console.log("📩 Login request for:", email);

    const user = await User.findOne({ email });
    if (!user) {
      console.log("❌ No user found with email:", email);
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    const ok = await bcrypt.compare(password, user.password);
    if (!ok) {
      console.log("❌ Wrong password for:", email);
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    const token = jwt.sign(
      { id: user._id, email: user.email },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
    );

    console.log("✅ Login success for:", email);

    res.json({
      message: 'Login success',
      token,
      user: { id: user._id, name: user.name, email: user.email }
    });
  } catch (e) {
    console.error("🔥 Login failed:", e.message);
    res.status(500).json({ message: 'Login failed', error: e.message });
  }
});

module.exports = router;