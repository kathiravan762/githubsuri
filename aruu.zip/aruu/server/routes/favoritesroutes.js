const express = require('express');
const authMiddleware =require("../middleware/auth.js");
const Favorite = require("../models/favorite.js");


const router = express.Router();

// 📌 Add to favorites
router.post("/add", authMiddleware, async (req, res) => {
  try {
    const { foodId } = req.body;
    const userId = req.user.id;

    // Check if already in favorites
    const exists = await Favorite.findOne({ userId, foodId });
    if (exists) return res.status(400).json({ message: "Already in favorites" });

    const fav = new Favorite({ userId, foodId });
    await fav.save();
    res.json({ message: "Added to favorites", fav });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 📌 Get all favorites for logged-in user
router.get("/my-favorites", authMiddleware, async (req, res) => {
  try {
    const userId = req.user.id;
    const favorites = await Favorite.find({ userId }).populate("foodId");
    res.json({ favorites });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 📌 Remove from favorites
router.delete("/:id", authMiddleware, async (req, res) => {
  try {
    const fav = await Favorite.findByIdAndDelete(req.params.id);
    res.json({ message: "Removed from favorites" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;