const express = require("express");
const router = express.Router();
const Order = require("./models/Order");
const nodemailer = require("nodemailer");

// Replace these with your real values or use dotenv
const ADMIN_EMAIL = "kathiravans762@gmail.com"; // receiver
const SENDER_EMAIL = "firestgaming@gmail.com"; // sender (must be Gmail)
const APP_PASSWORD = "bmrtsqmjqgmugcem"; // Gmail app password

// Email sending function
const sendEmailToAdmin = async (order) => {
  const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: SENDER_EMAIL,
      pass: APP_PASSWORD
    }
  });

  const foodList = order.foodItems
    .map(item => $`{item.name}` (x$`{item.quantity}`))
    .join(", ");

  const mailOptions = {
    from: SENDER_EMAIL,
    to: ADMIN_EMAIL,
    subject: "✅ New Order Received",
    text: `A new order has been placed by ${order.email}.

🧾 Order Details:
- Items: ${foodList}
- Total Price: ₹${order.totalPrice}
- Time: ${new Date(order.createdAt).toLocaleString()}
`
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log("✅ Email sent to admin.");
  } catch (error) {
    console.error("❌ Email sending error:", error);
  }
};

// POST route to place order
router.post("/api/order", async (req, res) => {
  try {
    const { foodItems, totalPrice, email } = req.body;

    const order = new Order({
      foodItems,
      totalPrice,
      email,
      createdAt: new Date()
    });

    await order.save();
    await sendEmailToAdmin(order);

    res.status(201).json({ message: "Order placed successfully" });
  } catch (err) {
    console.error("❌ Order placement error:", err);
    res.status(500).json({ error: "Failed to place order" });
  }
});

module.exports = router;